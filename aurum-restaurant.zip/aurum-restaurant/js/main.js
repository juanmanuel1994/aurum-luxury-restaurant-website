/* ============================================================
   AURUM — main.js
   Pure vanilla JS — no dependencies
   ============================================================ */

(function () {
  'use strict';

  /* ---------- Nav: scroll behaviour ---------- */
  var nav = document.getElementById('mainNav');
  if (nav) {
    var onScroll = function () {
      if (window.scrollY > 40) {
        nav.classList.add('scrolled');
      } else {
        /* Only remove on home page (hero exists) */
        if (document.getElementById('hero')) {
          nav.classList.remove('scrolled');
        }
      }
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  /* ---------- Nav: mobile toggle ---------- */
  var toggle   = document.getElementById('navToggle');
  var mobileNav = document.getElementById('navMobile');
  if (toggle && mobileNav) {
    toggle.addEventListener('click', function () {
      var open = mobileNav.classList.toggle('open');
      toggle.classList.toggle('open', open);
      document.body.style.overflow = open ? 'hidden' : '';
    });
    /* Close on link click */
    mobileNav.querySelectorAll('a').forEach(function (a) {
      a.addEventListener('click', function () {
        mobileNav.classList.remove('open');
        toggle.classList.remove('open');
        document.body.style.overflow = '';
      });
    });
  }

  /* ---------- Animate on scroll ---------- */
  var animEls = document.querySelectorAll('.anim');
  if ('IntersectionObserver' in window && animEls.length) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

    animEls.forEach(function (el) { io.observe(el); });
  } else {
    /* Fallback: show all immediately */
    animEls.forEach(function (el) { el.classList.add('visible'); });
  }

  /* ---------- Menu tabs (menu.html) ---------- */
  var menuTabs = document.querySelectorAll('.menu-tab');
  var menuPanels = document.querySelectorAll('.menu-panel');
  if (menuTabs.length) {
    menuTabs.forEach(function (tab) {
      tab.addEventListener('click', function () {
        var target = tab.getAttribute('data-target');

        /* Update tab styles */
        menuTabs.forEach(function (t) {
          t.style.borderBottomColor = 'transparent';
          t.style.color = 'var(--text-muted)';
          t.classList.remove('active');
        });
        tab.style.borderBottomColor = 'var(--gold)';
        tab.style.color = 'var(--gold)';
        tab.classList.add('active');

        /* Show/hide panels */
        menuPanels.forEach(function (panel) {
          panel.style.display = panel.id === target ? 'block' : 'none';
        });

        /* Re-trigger animations for newly visible items */
        var newAnims = document.querySelectorAll('#' + target + ' .anim:not(.visible)');
        newAnims.forEach(function (el) { el.classList.add('visible'); });
      });
    });
  }

  /* ---------- Accordion (FAQ) ---------- */
  var accordionItems = document.querySelectorAll('.accordion-item');
  accordionItems.forEach(function (item) {
    var trigger = item.querySelector('.accordion-trigger');
    if (!trigger) return;
    trigger.addEventListener('click', function () {
      var isOpen = item.classList.contains('open');
      /* Close all */
      accordionItems.forEach(function (i) { i.classList.remove('open'); });
      /* Open clicked if it was closed */
      if (!isOpen) item.classList.add('open');
    });
  });

  /* ---------- Reservation Form ---------- */
  var reservationForm = document.getElementById('reservationForm');
  if (reservationForm) {
    /* Set min date to today */
    var dateInput = document.getElementById('date');
    if (dateInput) {
      var today = new Date();
      var yyyy  = today.getFullYear();
      var mm    = String(today.getMonth() + 1).padStart(2, '0');
      var dd    = String(today.getDate()).padStart(2, '0');
      dateInput.min = yyyy + '-' + mm + '-' + dd;
    }

    reservationForm.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!validateForm(reservationForm)) return;
      /* Simulate async submit */
      var btn = reservationForm.querySelector('[type="submit"]');
      btn.disabled = true;
      btn.textContent = 'Processing…';
      setTimeout(function () {
        reservationForm.style.display = 'none';
        var success = document.getElementById('formSuccess');
        if (success) success.style.display = 'block';
      }, 900);
    });
  }

  /* ---------- Contact Form ---------- */
  var contactForm = document.getElementById('contactForm');
  if (contactForm) {
    contactForm.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!validateForm(contactForm)) return;
      var btn = contactForm.querySelector('[type="submit"]');
      btn.disabled = true;
      btn.textContent = 'Sending…';
      setTimeout(function () {
        contactForm.style.display = 'none';
        var success = document.getElementById('contactSuccess');
        if (success) success.style.display = 'block';
      }, 900);
    });
  }

  /* ---------- Form validation helper ---------- */
  function validateForm(form) {
    var valid = true;
    form.querySelectorAll('[required]').forEach(function (field) {
      var val = field.value.trim();
      var isCheckbox = field.type === 'checkbox';
      var isEmpty = isCheckbox ? !field.checked : !val;
      if (isEmpty) {
        field.style.borderColor = '#b85a4a';
        valid = false;
        field.addEventListener('input', function clearError() {
          field.style.borderColor = '';
          field.removeEventListener('input', clearError);
        }, { once: true });
        field.addEventListener('change', function clearError() {
          field.style.borderColor = '';
          field.removeEventListener('change', clearError);
        }, { once: true });
      } else {
        field.style.borderColor = '';
      }
      /* Basic email check */
      if (field.type === 'email' && val) {
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val)) {
          field.style.borderColor = '#b85a4a';
          valid = false;
        }
      }
    });
    if (!valid) {
      var first = form.querySelector('[style*="b85a4a"]');
      if (first) first.focus();
    }
    return valid;
  }

  /* ---------- Lazy-load images ---------- */
  var lazyImgs = document.querySelectorAll('img.lazy');
  if ('IntersectionObserver' in window && lazyImgs.length) {
    var imgObserver = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          var img = entry.target;
          img.addEventListener('load', function () {
            img.classList.add('loaded');
          });
          img.addEventListener('error', function () {
            img.classList.add('loaded'); /* show broken img rather than staying invisible */
          });
          /* trigger load — src is already set, just add the class once loaded */
          if (img.complete) {
            img.classList.add('loaded');
          }
          imgObserver.unobserve(img);
        }
      });
    }, { rootMargin: '200px 0px' });
    lazyImgs.forEach(function (img) { imgObserver.observe(img); });
  } else {
    lazyImgs.forEach(function (img) { img.classList.add('loaded'); });
  }

  /* ---------- Smooth active nav link detection ---------- */
  var currentPage = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-links a').forEach(function (link) {
    var href = link.getAttribute('href');
    if (href === currentPage || (currentPage === '' && href === 'index.html')) {
      link.classList.add('active');
    } else {
      link.classList.remove('active');
    }
  });

})();
